﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btn_Calcular_Click(object sender, EventArgs e)
        {

            double valorA, valorB, valorC;

            if (Double.TryParse(txtbox_A.Text, out valorA) && Double.TryParse(txtbox_B.Text, out valorB) && Double.TryParse(txtbox_C.Text, out valorC))
            {

                bool CondA, CondB, CondC;

                CondA = valorA < (valorB + valorC) && valorA > Math.Abs(valorB - valorC);
                CondB = valorB < (valorA + valorC) && valorB > Math.Abs(valorA - valorC);
                CondC = valorC < (valorA + valorB) && valorC > Math.Abs(valorA - valorB);
                
                if(CondA && CondB && CondC)
                {
                 
                    if(valorA == valorB && valorB == valorC)
                    {
                        txt_Resultado.Text = "Os valores informados formam um triângulo equilátero.";
                        txt_Resultado.ForeColor = Color.Green;
                    }
                    else if (valorA != valorB && valorB != valorC && valorA != valorC)
                    {
                        txt_Resultado.Text = "Os valores informados formam um triângulo escaleno.";
                        txt_Resultado.ForeColor = Color.Green;
                    }
                    else
                    {
                        txt_Resultado.Text = "Os valores informados formam um triângulo isósceles.";
                        txt_Resultado.ForeColor = Color.Green;
                    }

                }
                else
                {
                    txt_Resultado.Text = "Os valores informados não formam um triângulo.";
                    txt_Resultado.ForeColor = Color.Red;

                };
            }
            else
            {
                MessageBox.Show("Um dos dados de entrada do triângulo é inválido!", "Erro!");
            }
        }

        private void Btn_Limpar_Click(object sender, EventArgs e)
        {
            txtbox_A.Text = "";
            txtbox_B.Text = "";
            txtbox_C.Text = "";
            txt_Resultado.Text = "";
        }

        private void Txtbox_A_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtbox_A, "");
            double valorA;

            if(!Double.TryParse(txtbox_A.Text, out valorA))
            {
                errorProvider1.SetError(txtbox_A, "O valor de A é invalido!");
            }
        }

        private void Txtbox_B_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtbox_B, "");
            double valorB;

            if (!Double.TryParse(txtbox_B.Text, out valorB))
            {
                errorProvider2.SetError(txtbox_B, "O valor de B é invalido!");
            }
        }

        private void Txtbox_C_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtbox_C, "");
            double valorC;

            if (!Double.TryParse(txtbox_C.Text, out valorC))
            {
                errorProvider3.SetError(txtbox_C, "O valor de C é invalido!");
            }
        }

        private void Btn_Sair_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
