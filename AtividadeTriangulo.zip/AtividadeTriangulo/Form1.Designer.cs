﻿namespace AtividadeTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_LabelLado = new System.Windows.Forms.Label();
            this.txt_LabelA = new System.Windows.Forms.Label();
            this.txt_LabelB = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_A = new System.Windows.Forms.TextBox();
            this.txtbox_B = new System.Windows.Forms.TextBox();
            this.txtbox_C = new System.Windows.Forms.TextBox();
            this.btn_Calcular = new System.Windows.Forms.Button();
            this.btn_Limpar = new System.Windows.Forms.Button();
            this.btn_Sair = new System.Windows.Forms.Button();
            this.txt_Resultado = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_LabelLado
            // 
            this.txt_LabelLado.AutoSize = true;
            this.txt_LabelLado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LabelLado.Location = new System.Drawing.Point(12, 22);
            this.txt_LabelLado.Name = "txt_LabelLado";
            this.txt_LabelLado.Size = new System.Drawing.Size(243, 29);
            this.txt_LabelLado.TabIndex = 3;
            this.txt_LabelLado.Text = "Lados Do Triângulo";
            // 
            // txt_LabelA
            // 
            this.txt_LabelA.AutoSize = true;
            this.txt_LabelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LabelA.Location = new System.Drawing.Point(44, 51);
            this.txt_LabelA.Name = "txt_LabelA";
            this.txt_LabelA.Size = new System.Drawing.Size(28, 29);
            this.txt_LabelA.TabIndex = 4;
            this.txt_LabelA.Text = "A";
            // 
            // txt_LabelB
            // 
            this.txt_LabelB.AutoSize = true;
            this.txt_LabelB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LabelB.Location = new System.Drawing.Point(130, 51);
            this.txt_LabelB.Name = "txt_LabelB";
            this.txt_LabelB.Size = new System.Drawing.Size(29, 29);
            this.txt_LabelB.TabIndex = 5;
            this.txt_LabelB.Text = "B";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(214, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 29);
            this.label2.TabIndex = 6;
            this.label2.Text = "C";
            // 
            // txtbox_A
            // 
            this.txtbox_A.Location = new System.Drawing.Point(29, 83);
            this.txtbox_A.Name = "txtbox_A";
            this.txtbox_A.Size = new System.Drawing.Size(60, 26);
            this.txtbox_A.TabIndex = 7;
            this.txtbox_A.Validated += new System.EventHandler(this.Txtbox_A_Validated);
            // 
            // txtbox_B
            // 
            this.txtbox_B.Location = new System.Drawing.Point(113, 83);
            this.txtbox_B.Name = "txtbox_B";
            this.txtbox_B.Size = new System.Drawing.Size(60, 26);
            this.txtbox_B.TabIndex = 8;
            this.txtbox_B.Validated += new System.EventHandler(this.Txtbox_B_Validated);
            // 
            // txtbox_C
            // 
            this.txtbox_C.Location = new System.Drawing.Point(195, 83);
            this.txtbox_C.Name = "txtbox_C";
            this.txtbox_C.Size = new System.Drawing.Size(60, 26);
            this.txtbox_C.TabIndex = 9;
            this.txtbox_C.Validated += new System.EventHandler(this.Txtbox_C_Validated);
            // 
            // btn_Calcular
            // 
            this.btn_Calcular.Location = new System.Drawing.Point(17, 501);
            this.btn_Calcular.Name = "btn_Calcular";
            this.btn_Calcular.Size = new System.Drawing.Size(194, 35);
            this.btn_Calcular.TabIndex = 10;
            this.btn_Calcular.Text = "Calcular";
            this.btn_Calcular.UseVisualStyleBackColor = true;
            this.btn_Calcular.Click += new System.EventHandler(this.Btn_Calcular_Click);
            // 
            // btn_Limpar
            // 
            this.btn_Limpar.AccessibleName = "btn_Limpar";
            this.btn_Limpar.Location = new System.Drawing.Point(237, 501);
            this.btn_Limpar.Name = "btn_Limpar";
            this.btn_Limpar.Size = new System.Drawing.Size(194, 35);
            this.btn_Limpar.TabIndex = 11;
            this.btn_Limpar.Text = "Limpar";
            this.btn_Limpar.UseVisualStyleBackColor = true;
            this.btn_Limpar.Click += new System.EventHandler(this.Btn_Limpar_Click);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(455, 501);
            this.btn_Sair.Name = "btn_Sair";
            this.btn_Sair.Size = new System.Drawing.Size(194, 35);
            this.btn_Sair.TabIndex = 12;
            this.btn_Sair.Text = "Sair";
            this.btn_Sair.UseVisualStyleBackColor = true;
            this.btn_Sair.Click += new System.EventHandler(this.Btn_Sair_Click);
            // 
            // txt_Resultado
            // 
            this.txt_Resultado.AutoSize = true;
            this.txt_Resultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Resultado.Location = new System.Drawing.Point(44, 151);
            this.txt_Resultado.Name = "txt_Resultado";
            this.txt_Resultado.Size = new System.Drawing.Size(0, 29);
            this.txt_Resultado.TabIndex = 13;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(932, 548);
            this.Controls.Add(this.txt_Resultado);
            this.Controls.Add(this.btn_Sair);
            this.Controls.Add(this.btn_Limpar);
            this.Controls.Add(this.btn_Calcular);
            this.Controls.Add(this.txtbox_C);
            this.Controls.Add(this.txtbox_B);
            this.Controls.Add(this.txtbox_A);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_LabelB);
            this.Controls.Add(this.txt_LabelA);
            this.Controls.Add(this.txt_LabelLado);
            this.Name = "Form1";
            this.Text = "Aplicativo de Verificação de Triângulos";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label txt_LabelLado;
        private System.Windows.Forms.Label txt_LabelA;
        private System.Windows.Forms.Label txt_LabelB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbox_A;
        private System.Windows.Forms.TextBox txtbox_B;
        private System.Windows.Forms.TextBox txtbox_C;
        private System.Windows.Forms.Button btn_Calcular;
        private System.Windows.Forms.Button btn_Limpar;
        private System.Windows.Forms.Button btn_Sair;
        private System.Windows.Forms.Label txt_Resultado;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}

